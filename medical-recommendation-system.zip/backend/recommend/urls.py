from django.urls import path
from. import views

urlpatterns = [
    path('recommend/<int:patient_id>/', views.recommend_doctors, name='recommend_doctors'),
]
    