import logging
from django.http import JsonResponse
from.models import Recommendation
from patients.models import Patient
from doctors.models import Doctor
from. recommend_algorithms import combined_recommendation
from django.core.cache import cache

logger = logging.getLogger(__name__)

def recommend_doctors(request, patient_id):
    """
    医生推荐视图
    """
    try:
        patient = Patient.objects.get(id=patient_id)
    except Patient.DoesNotExist:
        logger.error(f"Patient with id {patient_id} not found in recommendation.")
        return JsonResponse({'error': 'Patient not found'}, status=404)

    # 尝试从缓存中获取推荐结果
    cache_key = f'recommended_doctors_{patient_id}'
    recommended_doctors = cache.get(cache_key)
    if recommended_doctors is None:
        recommended_doctors = combined_recommendation(patient)
        # 将推荐结果存入缓存
        cache.set(cache_key, recommended_doctors, 60 * 15)  # 缓存15分钟

    doctor_list = []
    for doctor in recommended_doctors:
        doctor_list.append({
            'id': doctor.id,
            'name': doctor.name,
            'department': doctor.department,
            'title': doctor.title,
            'expertise': doctor.expertise,
            'schedule': doctor.schedule,
            'location': doctor.location
        })
        try:
            Recommendation.objects.create(patient=patient, doctor=doctor)
        except Exception as e:
            logger.error(f"Error creating recommendation for patient {patient_id} and doctor {doctor.id}: {e}")

    return JsonResponse({
        'patient': {
            'id': patient.id,
            'name': patient.name,
            'age': patient.age,
            'contact': patient.contact,
            'symptoms': patient.symptoms,
            'disease_history': patient.disease_history,
            'allergy_history': patient.allergy_history
        },
        'recommended_doctors': doctor_list
    })
    