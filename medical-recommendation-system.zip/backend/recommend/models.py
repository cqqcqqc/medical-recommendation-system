from django.db import models
from patients.models import Patient
from doctors.models import Doctor

class Recommendation(models.Model):
    """
    推荐信息模型
    """
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
    doctor = models.ForeignKey(Doctor, on_delete=models.CASCADE)
    recommendation_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Recommendation for {self.patient.name} to {self.doctor.name}'
    