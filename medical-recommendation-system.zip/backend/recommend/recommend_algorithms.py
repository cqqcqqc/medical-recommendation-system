from patients.models import Patient
from doctors.models import Doctor
import math

def content_based_recommendation(patient):
    """
    基于内容的推荐算法
    """
    recommended_doctors = []
    patient_symptoms = patient.symptoms.lower()
    patient_disease_history = patient.disease_history.lower()
    patient_allergy_history = patient.allergy_history.lower()
    doctors = Doctor.objects.all()
    for doctor in doctors:
        doctor_expertise = doctor.expertise.lower()
        symptom_score = sum([1 for sym in patient_symptoms.split() if sym in doctor_expertise])
        disease_score = sum([1 for dis in patient_disease_history.split() if dis in doctor_expertise])
        allergy_score = sum([1 for allg in patient_allergy_history.split() if allg in doctor_expertise])
        total_score = symptom_score + disease_score + allergy_score
        if total_score > 0:
            recommended_doctors.append((doctor, total_score))
    recommended_doctors.sort(key=lambda x: x[1], reverse=True)
    return [doctor for doctor, _ in recommended_doctors]

def collaborative_filtering_recommendation(patient):
    """
    协同过滤推荐算法
    """
    similar_patients = Patient.objects.filter(
        symptoms__icontains=patient.symptoms,
        disease_history__icontains=patient.disease_history,
        allergy_history__icontains=patient.allergy_history
    ).exclude(id=patient.id)
    recommended_doctors = []
    doctor_count = {}
    for similar_patient in similar_patients:
        for doctor in similar_patient.doctor_set.all():
            if doctor in doctor_count:
                doctor_count[doctor] += 1
            else:
                doctor_count[doctor] = 1
    sorted_doctors = sorted(doctor_count.items(), key=lambda item: item[1], reverse=True)
    for doctor, count in sorted_doctors:
        recommended_doctors.append(doctor)
    return recommended_doctors

def combined_recommendation(patient):
    """
    综合推荐算法
    """
    content_based = content_based_recommendation(patient)
    collaborative = collaborative_filtering_recommendation(patient)
    all_recommended = list(set(content_based + collaborative))
    content_dict = {doctor: idx for idx, doctor in enumerate(content_based)}
    collab_dict = {doctor: idx for idx, doctor in enumerate(collaborative)}
    all_recommended.sort(key=lambda doctor: (
        content_dict.get(doctor, math.inf),
        collab_dict.get(doctor, math.inf)
    ))
    return all_recommended
    