import logging
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from.models import Doctor
from django.core.exceptions import ValidationError
from django.core.cache import cache

logger = logging.getLogger(__name__)

@csrf_exempt
def doctor_info_entry(request):
    """
    医生信息录入视图
    """
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            name = data.get('name')
            department = data.get('department')
            title = data.get('title')
            expertise = data.get('expertise')
            schedule = data.get('schedule')
            location = data.get('location')

            if not all([name, department, title, expertise, schedule, location]):
                return JsonResponse({'error': 'All fields are required'}, status=400)

            doctor = Doctor(
                name=name,
                department=department,
                title=title,
                expertise=expertise,
                schedule=schedule,
                location=location
            )
            try:
                doctor.full_clean()
                doctor.save()
                # 清除医生列表缓存
                cache.delete('doctor_list')
                return JsonResponse({'message': 'Doctor created successfully', 'id': doctor.id})
            except ValidationError as e:
                logger.error(f"Validation error in doctor entry: {e.message_dict}")
                return JsonResponse({'error': e.message_dict}, status=400)
        except json.JSONDecodeError:
            logger.error("Invalid JSON data in doctor entry")
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)
        except Exception as e:
            logger.error(f"Unexpected error in doctor entry: {e}")
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@csrf_exempt
def doctor_info_update(request, doctor_id):
    """
    医生信息更新视图
    """
    try:
        doctor = Doctor.objects.get(id=doctor_id)
    except Doctor.DoesNotExist:
        return JsonResponse({'error': 'Doctor not found'}, status=404)

    if request.method == 'PUT':
        try:
            data = json.loads(request.body)
            doctor.name = data.get('name', doctor.name)
            doctor.department = data.get('department', doctor.department)
            doctor.title = data.get('title', doctor.title)
            doctor.expertise = data.get('expertise', doctor.expertise)
            doctor.schedule = data.get('schedule', doctor.schedule)
            doctor.location = data.get('location', doctor.location)
            try:
                doctor.full_clean()
                doctor.save()
                # 清除医生列表缓存
                cache.delete('doctor_list')
                return JsonResponse({'message': 'Doctor updated successfully'})
            except ValidationError as e:
                logger.error(f"Validation error in doctor update: {e.message_dict}")
                return JsonResponse({'error': e.message_dict}, status=400)
        except json.JSONDecodeError:
            logger.error("Invalid JSON data in doctor update")
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)
        except Exception as e:
            logger.error(f"Unexpected error in doctor update: {e}")
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

def doctor_info_query(request):
    """
    医生信息查询视图
    """
    if request.method == 'GET':
        # 尝试从缓存中获取医生列表
        doctor_list = cache.get('doctor_list')
        if doctor_list is None:
            doctors = Doctor.objects.all()
            doctor_list = []
            for doctor in doctors:
                doctor_list.append({
                    'id': doctor.id,
                    'name': doctor.name,
                    'department': doctor.department,
                    'title': doctor.title,
                    'expertise': doctor.expertise,
                    'schedule': doctor.schedule,
                    'location': doctor.location
                })
            # 将医生列表存入缓存
            cache.set('doctor_list', doctor_list, 60 * 15)  # 缓存15分钟
        return JsonResponse({'doctors': doctor_list})
    return JsonResponse({'error': 'Invalid request method'}, status=405)

def doctor_info_detail(request, doctor_id):
    """
    医生信息详情视图
    """
    try:
        doctor = Doctor.objects.get(id=doctor_id)
        doctor_data = {
            'id': doctor.id,
            'name': doctor.name,
            'department': doctor.department,
            'title': doctor.title,
            'expertise': doctor.expertise,
            'schedule': doctor.schedule,
            'location': doctor.location
        }
        return JsonResponse(doctor_data)
    except Doctor.DoesNotExist:
        return JsonResponse({'error': 'Doctor not found'}, status=404)
    