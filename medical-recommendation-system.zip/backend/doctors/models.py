from django.db import models
import re
from django.core.exceptions import ValidationError

class Doctor(models.Model):
    """
    医生信息模型
    """
    name = models.CharField(max_length=100)
    department = models.CharField(max_length=100)
    title = models.CharField(max_length=100)
    expertise = models.TextField()
    schedule = models.TextField()
    location = models.CharField(max_length=100)

    def clean(self):
        if not re.match(r'^[a-zA-Z\s]+$', self.name):
            raise ValidationError({'name': 'Name should only contain letters and spaces.'})
        if not re.match(r'^[a-zA-Z\s]+$', self.department):
            raise ValidationError({'department': 'Department should only contain letters and spaces.'})
        if not re.match(r'^[a-zA-Z\s]+$', self.title):
            raise ValidationError({'title': 'Title should only contain letters and spaces.'})

    def __str__(self):
        return self.name
    