from django.urls import path
from. import views

urlpatterns = [
    path('info/entry/', views.doctor_info_entry, name='doctor_info_entry'),
    path('info/update/<int:doctor_id>/', views.doctor_info_update, name='doctor_info_update'),
    path('info/query/', views.doctor_info_query, name='doctor_info_query'),
    path('info/detail/<int:doctor_id>/', views.doctor_info_detail, name='doctor_info_detail'),
]
    