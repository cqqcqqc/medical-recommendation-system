from django.urls import path
from. import views

urlpatterns = [
    path('info/entry/', views.patient_info_entry, name='patient_info_entry'),
    path('info/edit/<int:patient_id>/', views.patient_info_edit, name='patient_info_edit'),
    path('info/list/', views.patient_info_list, name='patient_info_list'),
    path('info/detail/<int:patient_id>/', views.patient_info_detail, name='patient_info_detail'),
]
    