import logging
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from.models import Patient
from django.core.exceptions import ValidationError
from django.core.cache import cache

logger = logging.getLogger(__name__)

@csrf_exempt
def patient_info_entry(request):
    """
    患者信息录入视图
    """
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            name = data.get('name')
            age = data.get('age')
            contact = data.get('contact')
            symptoms = data.get('symptoms')
            disease_history = data.get('disease_history')
            allergy_history = data.get('allergy_history')

            if not all([name, age, contact, symptoms, disease_history, allergy_history]):
                return JsonResponse({'error': 'All fields are required'}, status=400)

            patient = Patient(
                name=name,
                age=age,
                contact=contact,
                symptoms=symptoms,
                disease_history=disease_history,
                allergy_history=allergy_history
            )
            try:
                patient.full_clean()
                patient.save()
                # 清除患者列表缓存
                cache.delete('patient_list')
                return JsonResponse({'message': 'Patient created successfully', 'id': patient.id})
            except ValidationError as e:
                logger.error(f"Validation error in patient entry: {e.message_dict}")
                return JsonResponse({'error': e.message_dict}, status=400)
        except json.JSONDecodeError:
            logger.error("Invalid JSON data in patient entry")
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)
        except Exception as e:
            logger.error(f"Unexpected error in patient entry: {e}")
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

@csrf_exempt
def patient_info_edit(request, patient_id):
    """
    患者信息编辑视图
    """
    try:
        patient = Patient.objects.get(id=patient_id)
    except Patient.DoesNotExist:
        return JsonResponse({'error': 'Patient not found'}, status=404)

    if request.method == 'PUT':
        try:
            data = json.loads(request.body)
            patient.name = data.get('name', patient.name)
            patient.age = data.get('age', patient.age)
            patient.contact = data.get('contact', patient.contact)
            patient.symptoms = data.get('symptoms', patient.symptoms)
            patient.disease_history = data.get('disease_history', patient.disease_history)
            patient.allergy_history = data.get('allergy_history', patient.allergy_history)
            try:
                patient.full_clean()
                patient.save()
                # 清除患者列表缓存
                cache.delete('patient_list')
                return JsonResponse({'message': 'Patient updated successfully'})
            except ValidationError as e:
                logger.error(f"Validation error in patient edit: {e.message_dict}")
                return JsonResponse({'error': e.message_dict}, status=400)
        except json.JSONDecodeError:
            logger.error("Invalid JSON data in patient edit")
            return JsonResponse({'error': 'Invalid JSON data'}, status=400)
        except Exception as e:
            logger.error(f"Unexpected error in patient edit: {e}")
            return JsonResponse({'error': str(e)}, status=400)
    return JsonResponse({'error': 'Invalid request method'}, status=405)

def patient_info_list(request):
    """
    患者信息列表视图
    """
    if request.method == 'GET':
        # 尝试从缓存中获取患者列表
        patient_list = cache.get('patient_list')
        if patient_list is None:
            patients = Patient.objects.all()
            patient_list = []
            for patient in patients:
                patient_list.append({
                    'id': patient.id,
                    'name': patient.name,
                    'age': patient.age,
                    'contact': patient.contact,
                    'symptoms': patient.symptoms,
                    'disease_history': patient.disease_history,
                    'allergy_history': patient.allergy_history
                })
            # 将患者列表存入缓存
            cache.set('patient_list', patient_list, 60 * 15)  # 缓存15分钟
        return JsonResponse({'patients': patient_list})
    return JsonResponse({'error': 'Invalid request method'}, status=405)

def patient_info_detail(request, patient_id):
    """
    患者信息详情视图
    """
    try:
        patient = Patient.objects.get(id=patient_id)
        patient_data = {
            'id': patient.id,
            'name': patient.name,
            'age': patient.age,
            'contact': patient.contact,
            'symptoms': patient.symptoms,
            'disease_history': patient.disease_history,
            'allergy_history': patient.allergy_history
        }
        return JsonResponse(patient_data)
    except Patient.DoesNotExist:
        return JsonResponse({'error': 'Patient not found'}, status=404)
    