from django.db import models
import re
from django.core.exceptions import ValidationError

class Patient(models.Model):
    """
    患者信息模型
    """
    name = models.CharField(max_length=100)
    age = models.IntegerField()
    contact = models.CharField(max_length=100)
    symptoms = models.TextField()
    disease_history = models.TextField()
    allergy_history = models.TextField()

    def clean(self):
        if not re.match(r'^[a-zA-Z\s]+$', self.name):
            raise ValidationError({'name': 'Name should only contain letters and spaces.'})
        if self.age < 0:
            raise ValidationError({'age': 'Age cannot be negative.'})
        if not re.match(r'^[0-9\s+-]+$', self.contact):
            raise ValidationError({'contact': 'Contact should only contain numbers, spaces, + and -.'})

    def __str__(self):
        return self.name
    